﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Data.Entity;

namespace DeliveryManagementAppTI_1
{
    public partial class ReportForm : Form
    {
        private readonly DeliveryContext _context;

        public ReportForm()
        {
            _context = new DeliveryContext();
            _context.Configuration.LazyLoadingEnabled = false;
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.Text = "Sales Report";
            this.Size = new Size(600, 400);
            this.BackColor = Color.FromArgb(230, 240, 250);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 10);

            var lblHeader = new Label
            {
                Text = "Sales Report",
                Location = new Point(20, 20),
                Size = new Size(280, 30),
                BackColor = Color.FromArgb(74, 144, 226),
                ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 12, FontStyle.Bold)
            };

            var txtReport = new TextBox
            {
                Name = "btnReport",
                Location = new Point(20, 70),
                Size = new Size(560, 200),
                Multiline = true,
                ReadOnly = true,
                Font = new Font("Segoe UI", 12),
                TextAlign = HorizontalAlignment.Left,
                BackColor = Color.FromArgb(245, 245, 245),
                BorderStyle = BorderStyle.FixedSingle
            };

            var btnBack = new Button
            {
                Name = "btnBack",
                Text = "Back",
                Location = new Point(150, 300),
                Size = new Size(150, 40),
                BackColor = Color.FromArgb(74, 144, 226),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnBack.Click += (s, e) => { new ClientForm().Show(); this.Close(); };

            var btnLogout = new Button
            {
                Name = "btnLogout",
                Text = "Logout",
                Location = new Point(310, 300),
                Size = new Size(150, 40),
                BackColor = Color.FromArgb(231, 76, 60),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnLogout.Click += (s, e) => { new LoginForm().Show(); this.Close(); };

            var cbLanguage = new ComboBox
            {
                Name = "cbLanguage",
                Location = new Point(480, 5),
                Size = new Size(100, 20),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Color.White
            };
            cbLanguage.Items.AddRange(new[] { "English", "Spanish" });
            cbLanguage.SelectedIndex = 0;
            cbLanguage.SelectedIndexChanged += (s, e) =>
            {
                LanguageManager.SetLanguage(cbLanguage.SelectedItem.ToString());
                LanguageManager.UpdateFormLanguage(this);
                LoadReport(txtReport);
            };

            Controls.AddRange(new Control[] { lblHeader, txtReport, btnBack, btnLogout, cbLanguage });

            if (!RoleManager.IsManager)
            {
                lblHeader.Text = "Access Denied";
                txtReport.Visible = false;
                btnBack.Location = new Point(150, 100);
                btnLogout.Location = new Point(310, 100);
            }
            else
            {
                LoadReport(txtReport);
            }

            LanguageManager.UpdateFormLanguage(this);
        }

        private void LoadReport(TextBox txtReport)
        {
            try
            {
                using (var context = new DeliveryContext())
                {
                    var orders = context.Orders.ToList();
                    foreach (var order in orders)
                    {
                        context.Entry(order).Collection(o => o.OrderItems).Load();
                        foreach (var item in order.OrderItems)
                        {
                            context.Entry(item).Reference(i => i.MenuItem).Load();
                        }
                    }

                    if (!orders.Any())
                    {
                        txtReport.Text = "No orders found.";
                    }
                    else
                    {
                        var delivered = orders.Where(o => o.Status == "Delivered").ToList();
                        var failed = orders.Where(o => o.Status == "Failed").ToList();
                        var totalDelivered = delivered.Count;
                        var totalFailed = failed.Count;
                        var revenue = delivered.SelectMany(o => o.OrderItems)
                                              .Sum(oi => oi.MenuItem != null ? oi.MenuItem.Price * oi.Quantity : 0);

                        txtReport.Text = "Total Orders: " + orders.Count + "\r\n" +
                                         "Pending Orders: " + orders.Count(o => o.Status == "Pending") + "\r\n" +
                                         "Underway Orders: " + orders.Count(o => o.Status == "Underway") + "\r\n" +
                                         "Ready Orders: " + orders.Count(o => o.Status == "Ready") + "\r\n" +
                                         "Delivered Orders: " + totalDelivered + "\r\n" +
                                         "Failed Orders: " + totalFailed + "\r\n" +
                                         "Total Revenue: €" + revenue.ToString("F2");
                    }
                }
            }
            catch (Exception ex)
            {
                txtReport.Text = "Error: " + ex.Message + "\r\n" +
                                 "Inner: " + (ex.InnerException?.Message ?? "None");
            }
        }
    }
}