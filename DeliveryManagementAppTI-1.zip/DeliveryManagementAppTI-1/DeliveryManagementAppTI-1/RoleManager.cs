﻿namespace DeliveryManagementAppTI_1
{
    public static class RoleManager
    {
        public static string CurrentRole { get; private set; } = "Manager"; // Default

        public static void SetRole(string role)
        {
            CurrentRole = role;
        }

        public static bool IsManager => CurrentRole == "Manager";
        public static bool IsWorker => CurrentRole == "Worker";
        public static bool IsDriver => CurrentRole == "Driver";
    }
}