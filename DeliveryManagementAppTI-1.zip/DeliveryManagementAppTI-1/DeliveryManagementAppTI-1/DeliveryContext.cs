﻿using System.Data.Entity;

namespace DeliveryManagementAppTI_1
{
    public class DeliveryContext : DbContext
    {
        public DeliveryContext() : base("name=DeliveryDB") { }

        public DbSet<MenuItem> MenuItems { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
    }

    public class MenuItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
    }

    public class Order
    {
        public Order()
        {
            OrderItems = new System.Collections.Generic.List<OrderItem>();
        }
        public int Id { get; set; }
        public string CustomerName { get; set; }
        public string CustomerPhone { get; set; }
        public string CustomerAddress { get; set; }
        public System.DateTime OrderDate { get; set; }
        public string Status { get; set; } // Updated to match SQL: Pending, Underway, Ready, Delivered, Failed
        public string ManagerName { get; set; }
        public virtual System.Collections.Generic.ICollection<OrderItem> OrderItems { get; set; }
    }

    public class OrderItem
    {
        public int Id { get; set; }
        public int OrderId { get; set; }
        public int MenuItemId { get; set; }
        public int Quantity { get; set; }
        public virtual MenuItem MenuItem { get; set; }
    }
}