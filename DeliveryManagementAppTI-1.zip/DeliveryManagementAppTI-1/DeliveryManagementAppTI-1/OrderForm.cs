﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace DeliveryManagementAppTI_1
{
    public partial class OrderForm : Form
    {
        private readonly DeliveryContext _context = new DeliveryContext();
        private readonly int _orderId;
        private System.Collections.Generic.List<MenuItem> selectedItems = new System.Collections.Generic.List<MenuItem>();
        private DataGridView dgvMenu;

        public OrderForm(int orderId)
        {
            _orderId = orderId;
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.Text = "Order Management";
            this.Size = new Size(800, 500);
            this.BackColor = Color.FromArgb(230, 240, 250);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 10);

            var lblHeader = new Label
            {
                Text = "Create Order",
                Location = new Point(20, 20),
                Size = new Size(380, 30), // Half width
                BackColor = Color.FromArgb(74, 144, 226),
                ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 12, FontStyle.Bold)
            };

            var lblMenu = new Label { Name = "lblMenu", Text = "Available Menu", Location = new Point(20, 70), Size = new Size(100, 20) };
            dgvMenu = new DataGridView { Location = new Point(20, 100), Size = new Size(300, 200), ReadOnly = true };
            var btnAddItem = new Button { Name = "btnAddMenu", Text = "Add Item", Location = new Point(330, 100), Size = new Size(150, 40), BackColor = Color.FromArgb(74, 144, 226), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            var btnEditItem = new Button { Name = "btnEditMenu", Text = "Edit Item", Location = new Point(330, 150), Size = new Size(150, 40), BackColor = Color.FromArgb(74, 144, 226), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            var btnDeleteItem = new Button { Name = "btnDeleteMenu", Text = "Delete Item", Location = new Point(330, 200), Size = new Size(150, 40), BackColor = Color.FromArgb(74, 144, 226), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10, FontStyle.Bold) };

            var lblOrderItems = new Label { Name = "lblOrderItems", Text = "Order Items", Location = new Point(500, 70), Size = new Size(100, 20) };
            var dgvOrderItems = new DataGridView { Location = new Point(500, 100), Size = new Size(260, 200), ReadOnly = true };
            var btnAddToOrder = new Button { Name = "btnAddToOrder", Text = "Add to Order", Location = new Point(330, 250), Size = new Size(150, 40), BackColor = Color.FromArgb(74, 144, 226), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            var btnPlaceOrder = new Button { Name = "btnPlaceOrder", Text = "Place Order", Location = new Point(610, 310), Size = new Size(150, 40), BackColor = Color.FromArgb(46, 204, 113), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10, FontStyle.Bold) };

            var btnBack = new Button
            {
                Name = "btnBack",
                Text = "Back",
                Location = new Point(20, 420),
                Size = new Size(150, 40),
                BackColor = Color.FromArgb(74, 144, 226),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnBack.Click += (s, e) => { new ClientForm().Show(); this.Close(); };

            var btnLogout = new Button
            {
                Name = "btnLogout",
                Text = "Logout",
                Location = new Point(340, 420),
                Size = new Size(150, 40),
                BackColor = Color.FromArgb(231, 76, 60),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnLogout.Click += (s, e) => { new LoginForm().Show(); this.Close(); };

            var cbLanguage = new ComboBox
            {
                Name = "cbLanguage",
                Location = new Point(680, 5),
                Size = new Size(100, 20),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Color.White
            };
            cbLanguage.Items.AddRange(new[] { "English", "Spanish" });
            cbLanguage.SelectedIndex = 0;
            cbLanguage.SelectedIndexChanged += (s, e) =>
            {
                LanguageManager.SetLanguage(cbLanguage.SelectedItem.ToString());
                LanguageManager.UpdateFormLanguage(this);
            };

            Controls.AddRange(new Control[] { lblHeader, lblMenu, dgvMenu, btnAddItem, btnEditItem, btnDeleteItem, lblOrderItems, dgvOrderItems, btnAddToOrder, btnPlaceOrder, btnBack, btnLogout, cbLanguage });

            btnAddItem.Click += (s, e) =>
            {
                var name = Interaction.InputBox("Enter item name:");
                if (decimal.TryParse(Interaction.InputBox("Enter item price:"), out decimal price))
                {
                    _context.MenuItems.Add(new MenuItem { Name = name, Price = price });
                    _context.SaveChanges();
                    LoadMenu();
                }
            };

            btnEditItem.Click += (s, e) =>
            {
                if (dgvMenu.SelectedRows.Count > 0)
                {
                    var item = (MenuItem)dgvMenu.SelectedRows[0].DataBoundItem;
                    var name = Interaction.InputBox("Edit item name:", "Edit", item.Name);
                    if (decimal.TryParse(Interaction.InputBox("Edit item price:", "Edit", item.Price.ToString()), out decimal price))
                    {
                        item.Name = name;
                        item.Price = price;
                        _context.SaveChanges();
                        LoadMenu();
                    }
                }
            };

            btnDeleteItem.Click += (s, e) =>
            {
                if (dgvMenu.SelectedRows.Count > 0)
                {
                    var item = (MenuItem)dgvMenu.SelectedRows[0].DataBoundItem;
                    _context.MenuItems.Remove(item);
                    _context.SaveChanges();
                    LoadMenu();
                }
            };

            btnAddToOrder.Click += (s, e) =>
            {
                if (dgvMenu.SelectedRows.Count > 0)
                {
                    var item = (MenuItem)dgvMenu.SelectedRows[0].DataBoundItem;
                    selectedItems.Add(item);
                    dgvOrderItems.DataSource = null;
                    dgvOrderItems.DataSource = selectedItems;
                }
            };

            btnPlaceOrder.Click += (s, e) =>
            {
                var order = _context.Orders.Find(_orderId);
                order.OrderItems = selectedItems.Select(i => new OrderItem { MenuItemId = i.Id, Quantity = 1 }).ToList();
                _context.SaveChanges();
                MessageBox.Show($"Saved Order ID: {order.Id}, Items: {order.OrderItems.Count}");
                new StatusForm().Show();
                this.Close();
            };

            if (!RoleManager.IsManager)
            {
                lblHeader.Text = "Access Denied";
                lblMenu.Visible = dgvMenu.Visible = btnAddItem.Visible = btnEditItem.Visible = btnDeleteItem.Visible = lblOrderItems.Visible = dgvOrderItems.Visible = btnAddToOrder.Visible = btnPlaceOrder.Visible = false;
                btnLogout.Location = new Point(500, 420);
            }

            LoadMenu();
            LanguageManager.UpdateFormLanguage(this);
        }

        private void LoadMenu()
        {
            var menuItems = _context.MenuItems.ToList();
            dgvMenu.DataSource = menuItems;
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // OrderForm
            // 
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Name = "OrderForm";
            this.Load += new System.EventHandler(this.OrderForm_Load);
            this.ResumeLayout(false);

        }

        private void OrderForm_Load(object sender, EventArgs e)
        {


        }
    }
}