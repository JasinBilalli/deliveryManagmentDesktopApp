﻿using System.Globalization;
using System.Threading;
using System.Windows.Forms;

namespace DeliveryManagementAppTI_1
{
    public static class LanguageManager
    {
        public static void SetLanguage(string language)
        {
            CultureInfo culture;
            if (language == "Spanish")
                culture = new CultureInfo("es-ES");
            else
                culture = new CultureInfo("en-US");

            Thread.CurrentThread.CurrentUICulture = culture;
            Thread.CurrentThread.CurrentCulture = culture;
        }

        public static void UpdateFormLanguage(Form form)
        {
            foreach (Control c in form.Controls)
            {
                if (c is ComboBox || c is Button || c is Label || c is DataGridView)
                {
                    c.Text = Properties.Resources.ResourceManager.GetString(c.Name, Thread.CurrentThread.CurrentUICulture) ?? c.Text;
                }
            }
        }
    }
}