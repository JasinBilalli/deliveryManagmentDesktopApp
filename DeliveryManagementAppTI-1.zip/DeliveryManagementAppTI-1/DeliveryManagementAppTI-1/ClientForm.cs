﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace DeliveryManagementAppTI_1
{
    public partial class ClientForm : Form
    {
        private readonly DeliveryContext _context = new DeliveryContext();

        public ClientForm()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.Text = "Client Management";
            this.Size = new Size(600, 400);
            this.BackColor = Color.FromArgb(230, 240, 250);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 10);

            var lblHeader = new Label
            {
                Text = "Add Client",
                Location = new Point(20, 20),
                Size = new Size(560, 30),
                BackColor = Color.FromArgb(74, 144, 226),
                ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 12, FontStyle.Bold)
            };

            var lblName = new Label { Name = "lblCustomerName", Text = "Customer Name", Location = new Point(20, 70), Size = new Size(100, 20) };
            var txtName = new TextBox { Location = new Point(130, 70), Size = new Size(200, 20) };
            var lblPhone = new Label { Name = "lblPhone", Text = "Phone", Location = new Point(20, 110), Size = new Size(100, 20) };
            var txtPhone = new TextBox { Location = new Point(130, 110), Size = new Size(200, 20) };
            var lblAddress = new Label { Name = "lblAddress", Text = "Address", Location = new Point(20, 150), Size = new Size(100, 20) };
            var txtAddress = new TextBox { Location = new Point(130, 150), Size = new Size(200, 20) };

            var btnAdd = new Button
            {
                Name = "btnPlaceOrder",
                Text = "Add Client & Order",
                Location = new Point(130, 190),
                Size = new Size(200, 40),
                BackColor = Color.FromArgb(74, 144, 226),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnAdd.Click += (s, e) =>
            {
                var order = new Order
                {
                    CustomerName = txtName.Text,
                    CustomerPhone = txtPhone.Text,
                    CustomerAddress = txtAddress.Text,
                    ManagerName = "Manager",
                    OrderDate = DateTime.Now,
                    Status = "Pending"
                };
                _context.Orders.Add(order);
                _context.SaveChanges();
                new OrderForm(order.Id).Show();
                this.Close();
            };

            var btnOrders = new Button
            {
                Text = "View Orders",
                Location = new Point(350, 70),
                Size = new Size(200, 40),
                BackColor = Color.FromArgb(74, 144, 226),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnOrders.Click += (s, e) => { new StatusForm().Show(); this.Close(); };

            var btnReport = new Button
            {
                Text = "Sales Report",
                Location = new Point(350, 120),
                Size = new Size(200, 40),
                BackColor = Color.FromArgb(74, 144, 226),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnReport.Click += (s, e) => { new ReportForm().Show(); this.Close(); };

            var btnLogout = new Button
            {
                Text = "Logout",
                Location = new Point(350, 170),
                Size = new Size(200, 40),
                BackColor = Color.FromArgb(231, 76, 60),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnLogout.Click += (s, e) => { new LoginForm().Show(); this.Close(); };

            var cbLanguage = new ComboBox
            {
                Name = "cbLanguage",
                Location = new Point(480, 5),
                Size = new Size(100, 20),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Color.White
            };
            cbLanguage.Items.AddRange(new[] { "English", "Spanish" });
            cbLanguage.SelectedIndex = 0;
            cbLanguage.SelectedIndexChanged += (s, e) =>
            {
                LanguageManager.SetLanguage(cbLanguage.SelectedItem.ToString());
                LanguageManager.UpdateFormLanguage(this);
            };

            Controls.AddRange(new Control[] { lblHeader, lblName, txtName, lblPhone, txtPhone, lblAddress, txtAddress, btnAdd, btnOrders, btnReport, btnLogout, cbLanguage });

            if (!RoleManager.IsManager)
            {
                lblHeader.Text = "Access Denied";
                lblName.Visible = txtName.Visible = lblPhone.Visible = txtPhone.Visible = lblAddress.Visible = txtAddress.Visible = btnAdd.Visible = false;
                btnOrders.Location = new Point(200, 100);
                btnReport.Visible = false;
                btnLogout.Location = new Point(200, 150);
            }

            LanguageManager.UpdateFormLanguage(this);
        }
    }
}