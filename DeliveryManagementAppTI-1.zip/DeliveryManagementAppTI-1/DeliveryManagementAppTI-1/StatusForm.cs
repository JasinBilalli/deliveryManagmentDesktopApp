﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace DeliveryManagementAppTI_1
{
    public partial class StatusForm : Form
    {
        private readonly DeliveryContext _context = new DeliveryContext();
        private DataGridView dgvOrders;

        public StatusForm()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.Text = "Order Status";
            this.Size = new Size(900, 600);
            this.BackColor = Color.FromArgb(230, 240, 250);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 10);

            var lblHeader = new Label
            {
                Text = "Order Status",
                Location = new Point(20, 20),
                Size = new Size(430, 30),
                BackColor = Color.FromArgb(74, 144, 226),
                ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 12, FontStyle.Bold)
            };

            var lblOrders = new Label { Name = "lblOrders", Text = "Current Orders", Location = new Point(20, 70), Size = new Size(100, 20) };
            dgvOrders = new DataGridView { Location = new Point(20, 100), Size = new Size(500, 400), ReadOnly = true };
            var dgvOrderItems = new DataGridView { Location = new Point(530, 100), Size = new Size(350, 400), ReadOnly = true };

            var btnUnderway = new Button { Name = "btnUnderway", Text = "Underway", Location = new Point(20, 510), Size = new Size(120, 40), BackColor = Color.FromArgb(243, 156, 18), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            var btnReady = new Button { Name = "btnReady", Text = "Ready", Location = new Point(150, 510), Size = new Size(120, 40), BackColor = Color.FromArgb(169, 223, 191), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            var btnDelivered = new Button { Name = "btnDelivered", Text = "Delivered", Location = new Point(280, 510), Size = new Size(120, 40), BackColor = Color.FromArgb(46, 204, 113), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            var btnFailed = new Button { Name = "btnFailed", Text = "Failed", Location = new Point(410, 510), Size = new Size(120, 40), BackColor = Color.FromArgb(231, 76, 60), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10, FontStyle.Bold) };

            var btnBack = new Button
            {
                Name = "btnBack",
                Text = "Back",
                Location = new Point(580, 510),
                Size = new Size(150, 40),
                BackColor = Color.FromArgb(74, 144, 226),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnBack.Click += (s, e) => { new ClientForm().Show(); this.Close(); };

            var btnLogout = new Button
            {
                Name = "btnLogout",
                Text = "Logout",
                Location = new Point(740, 510),
                Size = new Size(150, 40),
                BackColor = Color.FromArgb(231, 76, 60),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnLogout.Click += (s, e) => { new LoginForm().Show(); this.Close(); };

            var cbLanguage = new ComboBox
            {
                Name = "cbLanguage",
                Location = new Point(780, 5),
                Size = new Size(100, 20),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Color.White
            };
            cbLanguage.Items.AddRange(new[] { "English", "Spanish" });
            cbLanguage.SelectedIndex = 0;
            cbLanguage.SelectedIndexChanged += (s, e) =>
            {
                LanguageManager.SetLanguage(cbLanguage.SelectedItem.ToString());
                LanguageManager.UpdateFormLanguage(this);
            };

            Controls.AddRange(new Control[] { lblHeader, lblOrders, dgvOrders, dgvOrderItems, btnUnderway, btnReady, btnDelivered, btnFailed, btnBack, btnLogout, cbLanguage });

            btnUnderway.Click += (s, e) => UpdateStatus("Underway");
            btnReady.Click += (s, e) => UpdateStatus("Ready");
            btnDelivered.Click += (s, e) => UpdateStatus("Delivered");
            btnFailed.Click += (s, e) => UpdateStatus("Failed");

            dgvOrders.SelectionChanged += (s, e) =>
            {
                if (dgvOrders.SelectedRows.Count > 0)
                {
                    var order = (Order)dgvOrders.SelectedRows[0].DataBoundItem;
                    dgvOrderItems.DataSource = order.OrderItems.ToList();
                }
            };

            dgvOrders.DataBindingComplete += (s, e) =>
            {
                foreach (DataGridViewRow row in dgvOrders.Rows)
                {
                    var order = (Order)row.DataBoundItem;
                    switch (order.Status)
                    {
                        case "Delivered":
                            row.DefaultCellStyle.BackColor = Color.FromArgb(232, 245, 233); // Very light green
                            break;
                        case "Pending":
                            row.DefaultCellStyle.BackColor = Color.White; // Default
                            break;
                        case "Underway":
                            row.DefaultCellStyle.BackColor = Color.FromArgb(255, 243, 224); // Very light orange
                            break;
                        case "Failed":
                            row.DefaultCellStyle.BackColor = Color.FromArgb(255, 235, 238); // Very light red
                            break;
                        case "Ready":
                            row.DefaultCellStyle.BackColor = Color.FromArgb(227, 242, 253); // Very light blue
                            break;
                    }
                }
            };

            if (RoleManager.IsWorker)
            {
                btnDelivered.Visible = btnFailed.Visible = false;
            }
            else if (RoleManager.IsDriver)
            {
                btnUnderway.Visible = btnReady.Visible = false;
            }

            LoadOrders();
            LanguageManager.UpdateFormLanguage(this);
        }

        private void LoadOrders()
        {
            var orders = _context.Orders.Include("OrderItems.MenuItem").ToList();
            dgvOrders.DataSource = orders;
        }

        private void UpdateStatus(string status)
        {
            if (dgvOrders.SelectedRows.Count > 0)
            {
                var order = (Order)dgvOrders.SelectedRows[0].DataBoundItem;
                if (RoleManager.IsWorker && (status == "Delivered" || status == "Failed")) return;
                if (RoleManager.IsDriver && (status == "Underway" || status == "Ready")) return;
                order.Status = status;
                _context.SaveChanges();
                LoadOrders();
            }
        }
    }
}