﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace DeliveryManagementAppTI_1
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.Text = "Login";
            this.Size = new Size(400, 300);
            this.BackColor = Color.FromArgb(230, 240, 250);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 10);

            var lblTitle = new Label
            {
                Text = "Select Role",
                Location = new Point(20, 20),
                Size = new Size(180, 30), // Half width from ComboBox side
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                ForeColor = Color.FromArgb(74, 144, 226)
            };

            var btnManager = new Button
            {
                Name = "btnManager",
                Text = "Login as Manager",
                Location = new Point(100, 80),
                Size = new Size(200, 40),
                BackColor = Color.FromArgb(74, 144, 226),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnManager.Click += (s, e) => Login("Manager");

            var btnWorker = new Button
            {
                Name = "btnWorker",
                Text = "Login as Worker",
                Location = new Point(100, 130),
                Size = new Size(200, 40),
                BackColor = Color.FromArgb(74, 144, 226),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnWorker.Click += (s, e) => Login("Worker");

            var btnDriver = new Button
            {
                Name = "btnDriver",
                Text = "Login as Driver",
                Location = new Point(100, 180),
                Size = new Size(200, 40),
                BackColor = Color.FromArgb(74, 144, 226),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnDriver.Click += (s, e) => Login("Driver");

            var cbLanguage = new ComboBox
            {
                Name = "cbLanguage",
                Location = new Point(280, 5),
                Size = new Size(100, 20),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Color.White
            };
            cbLanguage.Items.AddRange(new[] { "English", "Spanish" });
            cbLanguage.SelectedIndex = 0;
            cbLanguage.SelectedIndexChanged += (s, e) =>
            {
                LanguageManager.SetLanguage(cbLanguage.SelectedItem.ToString());
                LanguageManager.UpdateFormLanguage(this);
            };

            Controls.AddRange(new Control[] { lblTitle, btnManager, btnWorker, btnDriver, cbLanguage });

            LanguageManager.UpdateFormLanguage(this);
        }

        private void Login(string role)
        {
            RoleManager.SetRole(role);
            new ClientForm().Show();
            this.Hide();
        }
    }
}